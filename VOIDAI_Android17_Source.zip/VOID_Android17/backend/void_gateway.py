"""
Optional VOID HTTPS AI gateway.
Run on a trusted server behind HTTPS (Caddy/Nginx/Tailscale Serve).
This replaces the old shell-executing MCP server: it never runs arbitrary commands
on Android, never handles lock-screen PINs, and never treats face detection as identity.
"""
import os
import hmac
import httpx
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

APP_TOKEN = os.environ["VOID_APP_TOKEN"]
AI_API_KEY = os.environ["AI_API_KEY"]
AI_BASE_URL = os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
AI_MODEL = os.getenv("AI_MODEL", "")

app = FastAPI(title="VOID Private AI Gateway", docs_url=None, redoc_url=None)

class ChatRequest(BaseModel):
    model: str | None = None
    messages: list[dict]
    stream: bool = False

@app.get("/health")
async def health():
    return {"service": "void-gateway", "status": "ok"}

@app.post("/v1/chat/completions")
async def chat(req: ChatRequest, authorization: str | None = Header(default=None)):
    supplied = (authorization or "").removeprefix("Bearer ").strip()
    if not supplied or not hmac.compare_digest(supplied, APP_TOKEN):
        raise HTTPException(status_code=401, detail="Unauthorized")

    payload = {
        "model": req.model or AI_MODEL,
        "messages": req.messages,
        "stream": False,
    }
    if not payload["model"]:
        raise HTTPException(status_code=500, detail="AI_MODEL is not configured")

    headers = {"Authorization": f"Bearer {AI_API_KEY}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=90) as client:
        try:
            response = await client.post(
                f"{AI_BASE_URL}/chat/completions",
                json=payload,
                headers=headers,
            )
        except httpx.HTTPError as exc:
            raise HTTPException(status_code=502, detail=f"Upstream AI unavailable: {exc}") from exc

    if response.status_code >= 400:
        # Do not return provider secrets or internal headers.
        return JSONResponse(
            status_code=502,
            content={"error": "Upstream AI request failed", "provider_status": response.status_code},
        )
    return JSONResponse(content=response.json())
