package com.void.personaladmin

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private val VoidBlack = Color(0xFF080808)
private val VoidPanel = Color(0xFF171313)
private val VoidRed = Color(0xFFB51E2B)
private val VoidDeepRed = Color(0xFF310D12)
private val VoidText = Color(0xFFF3EDEE)
private val VoidMuted = Color(0xFFAA9B9E)

data class ChatLine(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 8, 8)
        window.navigationBarColor = android.graphics.Color.rgb(8, 8, 8)
        setContent { VoidTheme { VoidHome() } }
    }
}

@Composable
private fun VoidTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = VoidRed,
            onPrimary = Color.White,
            background = VoidBlack,
            surface = VoidPanel,
            onSurface = VoidText,
            secondary = Color(0xFFD45A64)
        ),
        content = content
    )
}

@Composable
private fun VoidHome() {
    val context = LocalContext.current
    val vault = remember { SecureVault(context) }
    val scope = rememberCoroutineScope()
    val lines = remember {
        mutableStateListOf(
            ChatLine("assistant", "I am VOID. Your private AI command center is ready. Configure an AI endpoint in Settings to enable cloud reasoning.")
        )
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var config by remember {
        mutableStateOf(
            runCatching {
                val j = JSONObject(vault.read("config") ?: "{}")
                AiConfig(j.optString("baseUrl"), j.optString("model"), j.optString("token"))
            }.getOrDefault(AiConfig())
        )
    }
    var status by remember { mutableStateOf(DeviceActions.battery(context)) }

    fun saveConfig(updated: AiConfig) {
        config = updated
        vault.write("config", JSONObject()
            .put("baseUrl", updated.baseUrl)
            .put("model", updated.model)
            .put("token", updated.token).toString())
    }

    fun sendCommand(raw: String) {
        val command = raw.trim()
        if (command.isBlank() || busy) return
        lines.add(ChatLine("user", command))
        input = ""
        val lower = command.lowercase()
        val local = when {
            lower == "battery" || lower.contains("battery status") -> DeviceActions.battery(context)
            lower == "volume up" || lower == "increase volume" || lower == "louder" -> DeviceActions.volume(context, true)
            lower == "volume down" || lower == "decrease volume" || lower == "quieter" -> DeviceActions.volume(context, false)
            lower.startsWith("open ") -> DeviceActions.openApp(context, command.substringAfter("open ").trim())
            lower.startsWith("search ") -> DeviceActions.search(context, command.substringAfter("search ").trim())
            lower == "open settings" -> DeviceActions.openSettings(context)
            lower == "open camera" -> DeviceActions.openCamera(context)
            lower == "lock screen" -> DeviceActions.lockScreen(context)
            lower.startsWith("remember ") -> {
                val old = vault.read("memory").orEmpty()
                val updated = (old.lines().filter { it.isNotBlank() } + command.substringAfter("remember ").trim()).takeLast(100)
                vault.write("memory", updated.joinToString("\n"))
                "Saved to your encrypted local VOID memory."
            }
            lower == "show memory" -> vault.read("memory")?.takeIf { it.isNotBlank() } ?: "Your local memory is empty."
            lower == "unlock phone" -> "For your safety, VOID cannot bypass or type your Android lock-screen PIN. Unlock the phone yourself using Android's secure lock screen."
            else -> null
        }

        if (local != null) {
            lines.add(ChatLine("assistant", local))
            status = DeviceActions.battery(context)
            return
        }

        busy = true
        val history = lines.map { it.role to it.text }.toList()
        scope.launch {
            val answer = withContext(Dispatchers.IO) {
                runCatching { VoidAiClient().complete(config, history) }
                    .getOrElse { "AI connection error: ${it.message ?: "unknown error"}" }
            }
            lines.add(ChatLine("assistant", answer))
            busy = false
        }
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) sendCommand(spoken)
        }
    }
    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to VOID")
            runCatching { voiceLauncher.launch(intent) }
                .onFailure { lines.add(ChatLine("assistant", "Speech recognition is not available on this device.")) }
        }
    }

    Scaffold(
        containerColor = VoidBlack,
        topBar = {
            Row(
                Modifier.fillMaxWidth().background(VoidBlack).padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(42.dp).background(
                        Brush.linearGradient(listOf(VoidRed, VoidDeepRed)), CircleShape
                    ),
                    contentAlignment = Alignment.Center
                ) { Text("V", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("VOID", color = VoidText, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                    Text("PERSONAL INTELLIGENCE", color = VoidMuted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = VoidRed)
                }
            }
        },
        bottomBar = {
            Column(Modifier.fillMaxWidth().background(VoidBlack).padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Command VOID...", color = VoidMuted) },
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VoidRed,
                            unfocusedBorderColor = Color(0xFF493338),
                            focusedTextColor = VoidText,
                            unfocusedTextColor = VoidText,
                            cursorColor = VoidRed
                        ),
                        maxLines = 3
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = {
                        micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice", tint = VoidRed)
                    }
                    IconButton(onClick = { sendCommand(input) }, enabled = !busy) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = if (busy) VoidMuted else VoidRed)
                    }
                }
                Text("ANDROID CONTROLS ARE PERMISSION-GATED • YOU STAY IN CONTROL",
                    color = VoidMuted, fontSize = 8.sp, letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 7.dp, start = 4.dp))
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                    .background(
                        Brush.horizontalGradient(listOf(VoidDeepRed, VoidPanel)),
                        RoundedCornerShape(18.dp)
                    ).padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(66.dp).background(VoidBlack, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("V", color = VoidRed, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("SYSTEM ONLINE", color = Color(0xFFE16A75), fontSize = 10.sp, letterSpacing = 2.sp)
                        Text("Your command center", color = VoidText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(status, color = VoidMuted, fontSize = 11.sp)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickTile("BATTERY", Icons.Default.BatteryFull, Modifier.weight(1f)) { lines.add(ChatLine("assistant", DeviceActions.battery(context))) }
                QuickTile("APPS", Icons.Default.Apps, Modifier.weight(1f)) { lines.add(ChatLine("assistant", "Try: open YouTube, open WhatsApp, or open Settings.")) }
                QuickTile("CAMERA", Icons.Default.CameraAlt, Modifier.weight(1f)) { lines.add(ChatLine("assistant", DeviceActions.openCamera(context))) }
                QuickTile("ADMIN", Icons.Default.AdminPanelSettings, Modifier.weight(1f)) { DeviceActions.requestDeviceAdmin(context) }
            }

            Text("CONVERSATION", color = VoidMuted, fontSize = 10.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 20.dp, top = 10.dp, bottom = 4.dp))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
                reverseLayout = false,
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(lines) { line ->
                    val user = line.role == "user"
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
                        Column(
                            Modifier.widthIn(max = 320.dp)
                                .background(if (user) VoidDeepRed else VoidPanel, RoundedCornerShape(16.dp))
                                .padding(horizontal = 14.dp, vertical = 11.dp)
                        ) {
                            Text(if (user) "YOU" else "VOID", color = if (user) Color(0xFFE17A83) else VoidRed,
                                fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Spacer(Modifier.height(3.dp))
                            Text(line.text, color = VoidText, fontSize = 14.sp)
                        }
                    }
                }
                if (busy) item { Text("VOID IS THINKING…", color = VoidRed, fontSize = 11.sp) }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            config = config,
            onSave = { saveConfig(it); showSettings = false },
            onClose = { showSettings = false },
            onAdmin = { DeviceActions.requestDeviceAdmin(context) }
        )
    }
}

@Composable
private fun QuickTile(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(72.dp),
        color = VoidPanel,
        shape = RoundedCornerShape(13.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3B2529))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, contentDescription = label, tint = VoidRed, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(5.dp))
            Text(label, color = VoidMuted, fontSize = 8.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
private fun SettingsDialog(
    config: AiConfig,
    onSave: (AiConfig) -> Unit,
    onClose: () -> Unit,
    onAdmin: () -> Unit
) {
    var url by remember { mutableStateOf(config.baseUrl) }
    var model by remember { mutableStateOf(config.model) }
    var token by remember { mutableStateOf(config.token) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = VoidPanel,
        title = { Text("VOID CONFIGURATION", color = VoidText, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("AI CONNECTION", color = VoidRed, fontSize = 10.sp, letterSpacing = 2.sp)
                OutlinedTextField(url, { url = it }, label = { Text("HTTPS API base URL") }, singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Model ID") }, singleLine = true)
                OutlinedTextField(
                    token, { token = it }, label = { Text("API / gateway token") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                Text("Prefer your own HTTPS gateway. A token stored on a phone can be extracted from a compromised device.",
                    color = VoidMuted, fontSize = 11.sp)
                Divider(color = Color(0xFF493338))
                Text("ANDROID ADMINISTRATION", color = VoidRed, fontSize = 10.sp, letterSpacing = 2.sp)
                Text("Optional legacy Device Administrator: permits screen-lock requests only. It does not unlock the phone or grant unrestricted access.",
                    color = VoidMuted, fontSize = 11.sp)
                OutlinedButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth()) {
                    Text("ACTIVATE DEVICE ADMIN")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(AiConfig(url.trim(), model.trim(), token.trim())) }) {
                Text("SAVE", color = VoidRed)
            }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("CANCEL", color = VoidMuted) } }
    )
}
