package com.void.personaladmin

import android.app.admin.DeviceAdminReceiver

/**
 * Optional, user-approved legacy Device Administrator receiver.
 * This is not Device Owner and does not provide unrestricted system access.
 */
class VoidDeviceAdminReceiver : DeviceAdminReceiver()
