package com.void.personaladmin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build

object DeviceActions {
    private val packages = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "whatsapp" to "com.whatsapp",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "spotify" to "com.spotify.music",
        "settings" to "com.android.settings"
    )

    fun battery(context: Context): String {
        val intent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return "Battery: $pct% • ${if (charging) "charging" else "not charging"}"
    }

    fun volume(context: Context, up: Boolean): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return if (up) "Media volume increased." else "Media volume decreased."
    }

    fun openApp(context: Context, name: String): String {
        val key = name.trim().lowercase()
        val packageName = packages[key] ?: key
        val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return "I couldn't find an installed app for '$name'. Try its package name."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return "Opened $name."
    }

    fun search(context: Context, query: String): String {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened a web search for: $query"
    }

    fun openSettings(context: Context): String {
        context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened Android Settings."
    }

    fun openCamera(context: Context): String {
        val intent = Intent("android.media.action.IMAGE_CAPTURE")
        if (intent.resolveActivity(context.packageManager) == null) return "No camera app is available."
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened the phone's camera app. Camera access remains under Android's permission controls."
    }

    fun requestDeviceAdmin(context: Context) {
        val component = ComponentName(context, VoidDeviceAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            .putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Allow VOID to lock the screen only when you explicitly ask it to."
            )
        context.startActivity(intent)
    }

    fun lockScreen(context: Context): String {
        val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val component = ComponentName(context, VoidDeviceAdminReceiver::class.java)
        if (!manager.isAdminActive(component)) return "Device Administrator is not enabled. Enable it in Settings first."
        manager.lockNow()
        return "Lock request sent to Android."
    }
}
