package com.void.personaladmin

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiConfig(
    val baseUrl: String = "",
    val model: String = "",
    val token: String = ""
)

class VoidAiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun complete(config: AiConfig, conversation: List<Pair<String, String>>): String {
        require(config.baseUrl.startsWith("https://")) {
            "Use an HTTPS AI endpoint. Plain HTTP endpoints are blocked for security."
        }
        require(config.model.isNotBlank()) { "Set your AI model name in Settings." }
        require(config.token.isNotBlank()) { "Set an API token or gateway token in Settings." }

        val base = config.baseUrl.trimEnd('/')
        val url = if (base.endsWith("/v1")) "$base/chat/completions"
                  else "$base/v1/chat/completions"

        val messages = JSONArray()
        messages.put(JSONObject()
            .put("role", "system")
            .put("content", "You are VOID, the user's personal AI assistant. Be clear and honest. " +
                "Never claim to have performed device actions unless the Android app confirms them. " +
                "Ask for confirmation before sensitive or irreversible actions."))
        conversation.takeLast(20).forEach { (role, content) ->
            messages.put(JSONObject().put("role", role).put("content", content))
        }

        val body = JSONObject()
            .put("model", config.model)
            .put("messages", messages)
            .put("stream", false)
            .toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer ${config.token}")
            .header("Content-Type", "application/json")
            .post(body)
            .build()

        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(raw).optString("error", raw) }.getOrDefault(raw)
                throw IllegalStateException("AI service returned HTTP ${response.code}: $detail")
            }
            val json = JSONObject(raw)
            return json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .optString("content")
                .ifBlank { "The AI service returned an empty response." }
        }
    }
}
