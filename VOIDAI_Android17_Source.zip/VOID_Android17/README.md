# VOID — Android 17 native starter

This is a rebuilt native Android project based on the code supplied in the conversation.
It replaces the WebView/Termux-as-the-phone-controller design with a Kotlin + Jetpack Compose app.

## What is implemented

- Matte black / dark blood-red native Compose interface.
- Chat interface and optional cloud AI connection using an OpenAI-compatible Chat Completions endpoint.
- AES-GCM encrypted local configuration and personal notes using Android Keystore.
- Voice-to-text command entry through Android speech recognition.
- Open supported installed apps, launch Android Settings, open camera app, web search.
- Read battery status and adjust media volume while the app is active.
- Optional user-approved legacy Device Administrator activation, limited to screen locking.
- Optional HTTPS Python gateway so the provider API key can remain on a server rather than inside the APK.

## Android 17 / Samsung target

The project is configured for `compileSdk = 37` and `targetSdk = 37` (Android 17).
Install the Android 17 SDK Platform (API 37) and a compatible recent Android Studio / Android Gradle Plugin.
The build uses JDK 17 and Gradle 8.13.

Open this folder in Android Studio and allow Gradle sync. If Android Studio asks to install SDK 37 or Build Tools 37, accept.

To build:
1. Open the project root in Android Studio.
2. Wait for Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio writes the debug APK under `app/build/outputs/apk/debug/`.

This environment did not have Android SDK / Gradle build tools available, so an APK has not been compiled or device-tested here. This is the complete source project to open and build, not a claim of a tested APK.

## Configure cloud AI

Open VOID > Settings and enter:
- HTTPS API base URL (for example `https://api.openai.com` or your own HTTPS gateway URL)
- Provider-supported model ID
- API token (prefer a gateway token, not a long-lived provider key)

The app appends `/v1/chat/completions` unless the base URL already ends in `/v1`.
Use only a model ID actually enabled for your provider/account. The old supplied IDs `qwen3.8-max` and `gpt-6` were not assumed to be valid.

**Security note:** encrypting a token at rest is not equivalent to making it impossible to extract from a rooted or compromised device. For production, use the optional gateway below and keep the upstream provider key on the server.

## Optional private gateway

On a trusted Linux/Windows host with Python 3.11+:

```bash
cd backend
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt

export VOID_APP_TOKEN='generate-a-long-random-secret'
export AI_API_KEY='your-provider-key'
export AI_BASE_URL='https://api.openai.com/v1'
export AI_MODEL='your-provider-supported-model'
uvicorn void_gateway:app --host 127.0.0.1 --port 8787
```

Use a reverse proxy or private VPN to expose it over HTTPS. Do not expose this development server directly to the public internet. Set the app's URL to the HTTPS gateway root and use `VOID_APP_TOKEN` as its token.

## Android administration: what is and is not possible

### Normal Device Administrator
Use Settings > Activate Device Admin in VOID. The user must approve the system screen. The only declared policy is `force-lock`, so VOID can request a screen lock. This does not grant root, unlock capability, arbitrary settings access, access to other apps' private data, or permission to silently control the device.

### Device Owner / fully managed provisioning
Device Owner is a different Android enterprise-management role. An ordinary installed APK cannot grant itself this role. Provisioning normally requires a freshly reset, eligible device and Android's managed-device setup / ADB provisioning flow. On a test device, the command shape is:

```bash
adb shell dpm set-device-owner com.void.personaladmin/.VoidDeviceAdminReceiver
```

This may be rejected if the device is already provisioned, has accounts, or Samsung firmware policy prevents the flow. Device Owner still does not mean unrestricted/root access. Back up your phone before any reset or provisioning experiment. Do not run this on your everyday phone without understanding the consequences.

### Capabilities deliberately not implemented
- Bypassing the lock screen, reading or typing the PIN, or silently unlocking.
- Root commands, arbitrary shell execution, hidden API calls, or disabling Android security.
- Automatic camera/microphone surveillance. Camera launch is user initiated; continuous vision needs a foreground service, CameraX, clear disclosure, and runtime permission.
- Silent SMS/call/contacts access, unrestricted file access, or silent Wi-Fi/Bluetooth toggling.
- Background always-on listening. Android restricts background microphone and camera access.

For broader workflows, add one permission-scoped Android feature at a time, with visible consent, a clear purpose, and audit history. Accessibility services are powerful and must not be enabled just to bypass app security or automate sensitive screens.

## What remains for later phases

1. CameraX vision with visible foreground notification and battery governor.
2. Foreground voice service with an explicit start/stop control.
3. Android 17 AppFunctions integration (API 37) so other compatible agents can discover VOID's approved tools.
4. Permission-scoped contacts/calendar/files integrations using Android pickers and system APIs.
5. Windows and Linux companion agents with mutual authentication and per-action approval.
6. Action queue, approval screen, audit log, and richer encrypted memory search.

The old `cv2.VideoCapture(0)` loop was removed: it is not a reliable Android camera API. The old `input keyevent`/ADB fallback, default PIN, default HMAC secret, and face-detection-as-biometric logic were removed for security and platform correctness.

## Important

- This is a functional starter, not a finished autonomous operating system.
- Test first on a spare device or emulator.
- Review all requested permissions before granting them.
- Never commit API keys, gateway tokens, signing keys, or passwords to source control.
